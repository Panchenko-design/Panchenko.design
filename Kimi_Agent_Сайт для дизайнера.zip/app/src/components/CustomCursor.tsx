import { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';

const CustomCursor = () => {
  const cursorRef = useRef<HTMLDivElement>(null);
  const trailRefs = useRef<HTMLDivElement[]>([]);
  const [isTouch, setIsTouch] = useState(false);
  const mousePos = useRef({ x: 0, y: 0 });

  useEffect(() => {
    // Check if touch device
    const checkTouch = () => {
      setIsTouch(window.matchMedia('(pointer: coarse)').matches);
    };
    checkTouch();
    window.addEventListener('resize', checkTouch);

    if (isTouch) return;

    const cursor = cursorRef.current;
    if (!cursor) return;

    const handleMouseMove = (e: MouseEvent) => {
      mousePos.current = { x: e.clientX, y: e.clientY };
      
      gsap.to(cursor, {
        x: e.clientX,
        y: e.clientY,
        duration: 0.08,
        ease: 'power2.out'
      });

      // Animate trails with delay
      trailRefs.current.forEach((trail, i) => {
        if (trail) {
          gsap.to(trail, {
            x: e.clientX,
            y: e.clientY,
            duration: 0.15 + i * 0.05,
            ease: 'power2.out'
          });
        }
      });
    };

    const handleMouseEnter = () => {
      gsap.to(cursor, { opacity: 1, duration: 0.3 });
      trailRefs.current.forEach(trail => {
        if (trail) gsap.to(trail, { opacity: 1, duration: 0.3 });
      });
    };

    const handleMouseLeave = () => {
      gsap.to(cursor, { opacity: 0, duration: 0.3 });
      trailRefs.current.forEach(trail => {
        if (trail) gsap.to(trail, { opacity: 0, duration: 0.3 });
      });
    };

    // Handle hover on interactive elements
    const handleElementHover = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      const isInteractive = target.closest('a, button, [data-cursor-hover]');
      
      if (isInteractive) {
        cursor.classList.add('hover');
      } else {
        cursor.classList.remove('hover');
      }
    };

    document.addEventListener('mousemove', handleMouseMove, { passive: true });
    document.addEventListener('mouseenter', handleMouseEnter);
    document.addEventListener('mouseleave', handleMouseLeave);
    document.addEventListener('mouseover', handleElementHover, { passive: true });

    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseenter', handleMouseEnter);
      document.removeEventListener('mouseleave', handleMouseLeave);
      document.removeEventListener('mouseover', handleElementHover);
      window.removeEventListener('resize', checkTouch);
    };
  }, [isTouch]);

  if (isTouch) return null;

  return (
    <>
      {/* Main cursor */}
      <div 
        ref={cursorRef}
        className="custom-cursor hidden md:block"
        style={{ opacity: 0 }}
      />
      
      {/* Cursor trails */}
      {[...Array(5)].map((_, i) => (
        <div
          key={i}
          ref={el => {
            if (el) trailRefs.current[i] = el;
          }}
          className="cursor-trail hidden md:block"
          style={{ 
            opacity: 0,
            width: `${8 - i}px`,
            height: `${8 - i}px`,
            background: `rgba(255, 45, 85, ${0.4 - i * 0.06})`
          }}
        />
      ))}
    </>
  );
};

export default CustomCursor;
