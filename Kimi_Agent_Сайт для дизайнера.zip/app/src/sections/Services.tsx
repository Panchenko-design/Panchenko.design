import { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Palette, Monitor, BookOpen, Film } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface Service {
  id: number;
  title: string;
  description: string;
  details: string[];
  icon: React.ElementType;
}

const services: Service[] = [
  {
    id: 1,
    title: 'БРЕНДИНГ',
    description: 'Создание уникальной визуальной идентичности, которая выделит ваш бренд среди конкурентов',
    details: ['Логотипы', 'Фирменный стиль', 'Брендбук', 'Гайдлайны'],
    icon: Palette
  },
  {
    id: 2,
    title: 'ВЕБ-ДИЗАЙН',
    description: 'Проектирование и дизайн цифровых интерфейсов, которые работают на результат',
    details: ['Сайты', 'Лендинги', 'Интерфейсы', 'Мобильные приложения'],
    icon: Monitor
  },
  {
    id: 3,
    title: 'ПОЛИГРАФИЯ',
    description: 'Дизайн печатной продукции, которая оставляет тактильное впечатление',
    details: ['Упаковка', 'Каталоги', 'Визитки', 'Editorial'],
    icon: BookOpen
  },
  {
    id: 4,
    title: 'МОУШН',
    description: 'Анимация и видео, которые оживляют ваш бренд и рассказывают историю',
    details: ['Анимация', 'Видео', 'Интерактив', '3D'],
    icon: Film
  }
];

const Services = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const titleRef = useRef<HTMLDivElement>(null);
  const accordionRef = useRef<HTMLDivElement>(null);
  const [activeIndex, setActiveIndex] = useState<number | null>(null);

  useEffect(() => {
    const section = sectionRef.current;
    const title = titleRef.current;
    const accordion = accordionRef.current;

    if (!section || !title || !accordion) return;

    const ctx = gsap.context(() => {
      // Title animation
      gsap.fromTo(title,
        { opacity: 0, y: 50 },
        {
          opacity: 1,
          y: 0,
          duration: 0.8,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: title,
            start: 'top 80%',
            toggleActions: 'play none none reverse'
          }
        }
      );

      // Accordion panels animation
      const panels = accordion.querySelectorAll('.accordion-panel');
      gsap.fromTo(panels,
        { opacity: 0, x: -30 },
        {
          opacity: 1,
          x: 0,
          duration: 0.6,
          stagger: 0.1,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: accordion,
            start: 'top 75%',
            toggleActions: 'play none none reverse'
          }
        }
      );
    }, section);

    return () => ctx.revert();
  }, []);

  const handlePanelClick = (index: number) => {
    setActiveIndex(activeIndex === index ? null : index);
  };

  return (
    <section 
      ref={sectionRef}
      id="services" 
      className="relative py-32 px-4 md:px-8 lg:px-16"
    >
      <div className="max-w-7xl mx-auto">
        {/* Section header */}
        <div ref={titleRef} className="mb-16">
          <p className="font-mono text-xs text-[#ff2d55] tracking-[0.3em] uppercase mb-4">
            Услуги
          </p>
          <h2 
            className="font-display font-bold text-[#f5f5f5] tracking-[-0.03em]"
            style={{ fontSize: 'clamp(2.5rem, 6vw, 4rem)' }}
          >
            ЧТО Я ДЕЛАЮ
          </h2>
        </div>

        {/* Accordion */}
        <div ref={accordionRef} className="space-y-0">
          {services.map((service, index) => {
            const Icon = service.icon;
            const isActive = activeIndex === index;

            return (
              <div
                key={service.id}
                className="accordion-panel border-t border-[#1a1a1a] last:border-b"
              >
                <button
                  onClick={() => handlePanelClick(index)}
                  className="w-full py-8 flex items-center justify-between group"
                  data-cursor-hover
                >
                  <div className="flex items-center gap-6">
                    <span className="font-mono text-sm text-[#888]">
                      {String(service.id).padStart(2, '0')}
                    </span>
                    <h3 
                      className={`font-display font-bold text-2xl md:text-4xl tracking-[-0.02em] transition-colors duration-300 ${
                        isActive ? 'text-[#ff2d55]' : 'text-[#f5f5f5] group-hover:text-[#ff2d55]'
                      }`}
                    >
                      {service.title}
                    </h3>
                  </div>
                  
                  <div className={`w-12 h-12 rounded-full border flex items-center justify-center transition-all duration-300 ${
                    isActive 
                      ? 'border-[#ff2d55] bg-[#ff2d55] rotate-45' 
                      : 'border-[#1a1a1a] group-hover:border-[#ff2d55]'
                  }`}>
                    <Icon className={`w-5 h-5 transition-colors ${
                      isActive ? 'text-white' : 'text-[#888] group-hover:text-[#ff2d55]'
                    }`} />
                  </div>
                </button>

                {/* Expandable content */}
                <div 
                  className={`overflow-hidden transition-all duration-500 ease-out ${
                    isActive ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'
                  }`}
                >
                  <div className="pb-8 pl-0 md:pl-16">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      <p className="text-[#888] leading-relaxed">
                        {service.description}
                      </p>
                      <div className="flex flex-wrap gap-3">
                        {service.details.map((detail, i) => (
                          <span 
                            key={i}
                            className="px-4 py-2 border border-[#1a1a1a] text-[#f5f5f5] font-mono text-xs tracking-wider"
                          >
                            {detail.toUpperCase()}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* CTA */}
        <div className="mt-16 text-center">
          <p className="text-[#888] mb-6">
            Не нашли нужную услугу? Давайте обсудим ваш проект
          </p>
          <a 
            href="#contact"
            className="inline-flex items-center gap-2 text-[#ff2d55] font-mono text-sm tracking-widest hover:underline"
            data-cursor-hover
          >
            СВЯЗАТЬСЯ
          </a>
        </div>
      </div>
    </section>
  );
};

export default Services;
