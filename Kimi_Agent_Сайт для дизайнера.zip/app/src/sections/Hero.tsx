import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ArrowDown } from 'lucide-react';

const Hero = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const nameRef = useRef<HTMLHeadingElement>(null);
  const subtitleRef = useRef<HTMLParagraphElement>(null);
  const navRef = useRef<HTMLDivElement>(null);
  const shapesRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    const name = nameRef.current;
    const subtitle = subtitleRef.current;
    const nav = navRef.current;
    const shapes = shapesRef.current;

    if (!section || !name || !subtitle || !nav || !shapes) return;

    const ctx = gsap.context(() => {
      // Split name into letters
      const letters = name.querySelectorAll('.letter');
      
      // Initial state
      gsap.set(letters, { 
        opacity: 0, 
        y: 100,
        rotateX: -90
      });
      gsap.set(subtitle, { opacity: 0, y: 30 });
      gsap.set(nav, { opacity: 0, y: 20 });

      // Animation timeline
      const tl = gsap.timeline({ delay: 0.3 });

      // Letters animation
      tl.to(letters, {
        opacity: 1,
        y: 0,
        rotateX: 0,
        duration: 1,
        stagger: 0.05,
        ease: 'back.out(1.7)'
      });

      // Subtitle animation
      tl.to(subtitle, {
        opacity: 1,
        y: 0,
        duration: 0.8,
        ease: 'power3.out'
      }, '-=0.5');

      // Navigation animation
      tl.to(nav, {
        opacity: 1,
        y: 0,
        duration: 0.6,
        ease: 'power3.out'
      }, '-=0.4');

      // Floating shapes animation
      const floatingShapes = shapes.querySelectorAll('.floating-shape');
      floatingShapes.forEach((shape, i) => {
        gsap.to(shape, {
          y: `+=${30 + i * 10}`,
          x: `+=${10 + i * 5}`,
          rotation: 360,
          duration: 8 + i * 2,
          repeat: -1,
          yoyo: true,
          ease: 'sine.inOut'
        });
      });

      // Parallax on mouse move
      const handleMouseMove = (e: MouseEvent) => {
        const { clientX, clientY } = e;
        const centerX = window.innerWidth / 2;
        const centerY = window.innerHeight / 2;
        const moveX = (clientX - centerX) / centerX;
        const moveY = (clientY - centerY) / centerY;

        gsap.to(shapes, {
          x: moveX * 30,
          y: moveY * 30,
          duration: 1,
          ease: 'power2.out'
        });

        gsap.to(name, {
          x: moveX * -10,
          y: moveY * -10,
          duration: 1,
          ease: 'power2.out'
        });
      };

      section.addEventListener('mousemove', handleMouseMove, { passive: true });

      return () => {
        section.removeEventListener('mousemove', handleMouseMove);
      };
    }, section);

    return () => ctx.revert();
  }, []);

  const scrollToWorks = () => {
    const worksSection = document.getElementById('works');
    if (worksSection) {
      worksSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const firstName = 'АЛЕКСАНДРА';
  const lastName = 'ВОЛКОВА';

  return (
    <section 
      ref={sectionRef}
      className="relative min-h-screen flex flex-col justify-center items-center overflow-hidden gradient-mesh grid-bg"
    >
      {/* Floating shapes */}
      <div ref={shapesRef} className="absolute inset-0 pointer-events-none">
        {/* Circle */}
        <div 
          className="floating-shape absolute w-32 h-32 md:w-48 md:h-48 rounded-full border border-[#ff2d55]/20 floating"
          style={{ top: '15%', left: '10%' }}
        />
        {/* Triangle */}
        <div 
          className="floating-shape absolute w-0 h-0 floating-delayed"
          style={{ 
            top: '20%', 
            right: '15%',
            borderLeft: '40px solid transparent',
            borderRight: '40px solid transparent',
            borderBottom: '70px solid rgba(0, 212, 255, 0.1)'
          }}
        />
        {/* Small circle */}
        <div 
          className="floating-shape absolute w-16 h-16 rounded-full bg-[#ff2d55]/10 floating"
          style={{ bottom: '25%', left: '20%' }}
        />
        {/* Square */}
        <div 
          className="floating-shape absolute w-20 h-20 border border-[#00d4ff]/20 rotate-45 floating-delayed"
          style={{ bottom: '30%', right: '10%' }}
        />
        {/* Gradient orb */}
        <div 
          className="floating-shape absolute w-64 h-64 rounded-full opacity-30 blur-3xl"
          style={{ 
            top: '50%', 
            left: '50%', 
            transform: 'translate(-50%, -50%)',
            background: 'radial-gradient(circle, rgba(255, 45, 85, 0.2) 0%, transparent 70%)'
          }}
        />
      </div>

      {/* Corner label */}
      <div className="absolute top-8 left-8 font-mono text-xs text-[#888] tracking-widest">
        ©2024 ПОРТФОЛИО
      </div>

      {/* Main content */}
      <div className="relative z-10 text-center px-4">
        {/* Name */}
        <h1 
          ref={nameRef}
          className="font-display font-bold text-[#f5f5f5] leading-none tracking-[-0.04em] text-3d"
          style={{ 
            fontSize: 'clamp(2.5rem, 10vw, 8rem)',
            perspective: '1000px'
          }}
        >
          <span className="block">
            {firstName.split('').map((letter, i) => (
              <span 
                key={i} 
                className="letter inline-block"
                style={{ transformStyle: 'preserve-3d' }}
              >
                {letter}
              </span>
            ))}
          </span>
          <span className="block mt-2">
            {lastName.split('').map((letter, i) => (
              <span 
                key={i} 
                className="letter inline-block"
                style={{ transformStyle: 'preserve-3d' }}
              >
                {letter}
              </span>
            ))}
          </span>
        </h1>

        {/* Subtitle */}
        <p 
          ref={subtitleRef}
          className="mt-8 font-mono text-sm md:text-base text-[#888] tracking-[0.2em] uppercase"
        >
          Графический дизайнер <span className="text-[#ff2d55]">&</span> Арт-директор
        </p>
      </div>

      {/* Bottom navigation */}
      <div 
        ref={navRef}
        className="absolute bottom-12 left-0 right-0 flex flex-col items-center gap-8"
      >
        <nav className="flex gap-8 md:gap-16">
          {['РАБОТЫ', 'ОБО МНЕ', 'КОНТАКТЫ'].map((item) => (
            <a
              key={item}
              href={`#${item === 'РАБОТЫ' ? 'works' : item === 'ОБО МНЕ' ? 'about' : 'contact'}`}
              className="font-mono text-xs md:text-sm text-[#888] hover:text-[#ff2d55] transition-colors tracking-widest link-underline"
              data-cursor-hover
            >
              {item}
            </a>
          ))}
        </nav>

        {/* Scroll indicator */}
        <button 
          onClick={scrollToWorks}
          className="flex flex-col items-center gap-2 text-[#888] hover:text-[#ff2d55] transition-colors"
          data-cursor-hover
        >
          <span className="font-mono text-xs tracking-widest">ЛИСТАЙТЕ</span>
          <ArrowDown className="w-4 h-4 animate-bounce" />
        </button>
      </div>
    </section>
  );
};

export default Hero;
