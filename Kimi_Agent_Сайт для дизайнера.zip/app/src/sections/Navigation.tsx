import { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { Menu, X } from 'lucide-react';

interface NavigationProps {
  visible: boolean;
}

const Navigation = ({ visible }: NavigationProps) => {
  const navRef = useRef<HTMLElement>(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const nav = navRef.current;
    if (!nav) return;

    gsap.to(nav, {
      y: visible ? 0 : -100,
      opacity: visible ? 1 : 0,
      duration: 0.4,
      ease: 'power3.out'
    });
  }, [visible]);

  const navLinks = [
    { name: 'РАБОТЫ', href: '#works' },
    { name: 'ОБО МНЕ', href: '#about' },
    { name: 'УСЛУГИ', href: '#services' },
    { name: 'КОНТАКТЫ', href: '#contact' },
  ];

  const handleLinkClick = () => {
    setMobileMenuOpen(false);
  };

  return (
    <>
      {/* Desktop Navigation */}
      <nav 
        ref={navRef}
        className="fixed top-0 left-0 right-0 z-50 glass opacity-0 -translate-y-full"
        style={{ opacity: 0 }}
      >
        <div className="max-w-7xl mx-auto px-4 md:px-8 lg:px-16 py-4 flex items-center justify-between">
          {/* Logo */}
          <a 
            href="#"
            className="font-display font-bold text-lg text-[#f5f5f5] tracking-tight"
            data-cursor-hover
          >
            AV.
          </a>

          {/* Desktop links */}
          <div className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="font-mono text-xs text-[#888] tracking-[0.15em] hover:text-[#ff2d55] transition-colors link-underline"
                data-cursor-hover
              >
                {link.name}
              </a>
            ))}
          </div>

          {/* Mobile menu button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden w-10 h-10 flex items-center justify-center text-[#f5f5f5]"
            data-cursor-hover
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </nav>

      {/* Mobile Menu */}
      <div 
        className={`fixed inset-0 z-40 bg-[#0a0a0a] transition-transform duration-500 md:hidden ${
          mobileMenuOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        <div className="flex flex-col items-center justify-center h-full gap-8">
          {navLinks.map((link, index) => (
            <a
              key={link.name}
              href={link.href}
              onClick={handleLinkClick}
              className="font-display font-bold text-3xl text-[#f5f5f5] hover:text-[#ff2d55] transition-colors"
              style={{ 
                animationDelay: `${index * 0.1}s`,
                opacity: mobileMenuOpen ? 1 : 0,
                transform: mobileMenuOpen ? 'translateY(0)' : 'translateY(20px)',
                transition: `all 0.5s ease ${index * 0.1}s`
              }}
            >
              {link.name}
            </a>
          ))}
        </div>
      </div>
    </>
  );
};

export default Navigation;
