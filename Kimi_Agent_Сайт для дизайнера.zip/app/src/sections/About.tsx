import { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

interface Stat {
  value: number;
  suffix: string;
  label: string;
}

const stats: Stat[] = [
  { value: 50, suffix: '+', label: 'Проектов' },
  { value: 30, suffix: '+', label: 'Клиентов' },
  { value: 6, suffix: '', label: 'Лет опыта' },
];

const About = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const statsRef = useRef<HTMLDivElement>(null);
  const [counters, setCounters] = useState<number[]>(stats.map(() => 0));
  const hasAnimated = useRef(false);

  useEffect(() => {
    const section = sectionRef.current;
    const image = imageRef.current;
    const content = contentRef.current;
    const statsContainer = statsRef.current;

    if (!section || !image || !content || !statsContainer) return;

    const ctx = gsap.context(() => {
      // Image reveal animation
      gsap.fromTo(image,
        { 
          opacity: 0, 
          scale: 1.1,
          filter: 'blur(20px)'
        },
        {
          opacity: 1,
          scale: 1,
          filter: 'blur(0px)',
          duration: 1.5,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: image,
            start: 'top 80%',
            toggleActions: 'play none none reverse'
          }
        }
      );

      // Content animation
      const contentElements = content.querySelectorAll('.animate-in');
      gsap.fromTo(contentElements,
        { opacity: 0, y: 40 },
        {
          opacity: 1,
          y: 0,
          duration: 0.8,
          stagger: 0.15,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: content,
            start: 'top 75%',
            toggleActions: 'play none none reverse'
          }
        }
      );

      // Stats counter animation
      ScrollTrigger.create({
        trigger: statsContainer,
        start: 'top 80%',
        onEnter: () => {
          if (!hasAnimated.current) {
            hasAnimated.current = true;
            stats.forEach((stat, index) => {
              const obj = { value: 0 };
              gsap.to(obj, {
                value: stat.value,
                duration: 2,
                ease: 'power2.out',
                onUpdate: () => {
                  setCounters(prev => {
                    const newCounters = [...prev];
                    newCounters[index] = Math.round(obj.value);
                    return newCounters;
                  });
                }
              });
            });
          }
        }
      });

      // Stats items animation
      const statItems = statsContainer.querySelectorAll('.stat-item');
      gsap.fromTo(statItems,
        { opacity: 0, y: 30 },
        {
          opacity: 1,
          y: 0,
          duration: 0.6,
          stagger: 0.1,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: statsContainer,
            start: 'top 85%',
            toggleActions: 'play none none reverse'
          }
        }
      );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section 
      ref={sectionRef}
      id="about" 
      className="relative py-32 px-4 md:px-8 lg:px-16"
    >
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 lg:gap-24 items-center">
          {/* Image */}
          <div ref={imageRef} className="relative">
            <div className="relative aspect-[3/4] overflow-hidden">
              <img
                src="/designer.jpg"
                alt="Александра Волкова"
                className="w-full h-full object-cover grayscale"
              />
              
              {/* Overlay gradient */}
              <div 
                className="absolute inset-0 mix-blend-overlay"
                style={{
                  background: 'linear-gradient(135deg, rgba(255, 45, 85, 0.3) 0%, rgba(0, 212, 255, 0.2) 100%)'
                }}
              />

              {/* Geometric overlay */}
              <div className="absolute inset-0 pointer-events-none">
                <div 
                  className="absolute top-1/4 right-0 w-32 h-32 border border-[#ff2d55]/30"
                  style={{ transform: 'translateX(50%) rotate(45deg)' }}
                />
                <div 
                  className="absolute bottom-1/4 left-0 w-24 h-24 border border-[#00d4ff]/30"
                  style={{ transform: 'translateX(-50%) rotate(45deg)' }}
                />
              </div>
            </div>

            {/* Experience badge */}
            <div className="absolute -bottom-6 -right-6 md:bottom-8 md:right-8 bg-[#0a0a0a] border border-[#1a1a1a] p-6">
              <p className="font-display font-bold text-4xl md:text-5xl text-[#ff2d55]">6+</p>
              <p className="font-mono text-xs text-[#888] tracking-widest mt-1">ЛЕТ ОПЫТА</p>
            </div>
          </div>

          {/* Content */}
          <div ref={contentRef} className="lg:pl-8">
            <p className="animate-in font-mono text-xs text-[#ff2d55] tracking-[0.3em] uppercase mb-6">
              Обо мне
            </p>
            
            <h2 className="animate-in font-display font-bold text-[#f5f5f5] tracking-[-0.03em] mb-8"
              style={{ fontSize: 'clamp(2rem, 5vw, 3.5rem)' }}
            >
              СОЗДАЮ<br />
              <span className="text-[#888]">ВИЗУАЛЬНЫЕ</span><br />
              ИСТОРИИ
            </h2>

            <div className="animate-in space-y-6 text-[#888] leading-relaxed">
              <p>
                Я верю, что дизайн — это не просто эстетика, а язык общения. 
                Каждый проект для меня — возможность рассказать уникальную историю 
                через форму, цвет и композицию.
              </p>
              <p>
                С 2018 года я помогаю брендам найти свой голос в визуальном шуме 
                современности. От стартапов до крупных компаний — каждый проект 
                получает индивидуальный подход и полное погружение в задачу.
              </p>
            </div>

            {/* Quote */}
            <div className="animate-in mt-10 pl-6 border-l-2 border-[#ff2d55]">
              <p className="font-display text-lg md:text-xl text-[#f5f5f5] italic leading-relaxed">
                «Хороший дизайн — это как хорошая шутка: если нужно объяснять, значит, что-то не так»
              </p>
            </div>

            {/* Stats */}
            <div ref={statsRef} className="animate-in mt-12 grid grid-cols-3 gap-8">
              {stats.map((stat, index) => (
                <div key={stat.label} className="stat-item">
                  <p className="font-display font-bold text-3xl md:text-4xl text-[#f5f5f5]">
                    {counters[index]}{stat.suffix}
                  </p>
                  <p className="font-mono text-xs text-[#888] tracking-widest mt-2">
                    {stat.label.toUpperCase()}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
