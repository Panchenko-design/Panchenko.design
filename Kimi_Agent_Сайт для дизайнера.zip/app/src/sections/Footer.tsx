import { ArrowUp } from 'lucide-react';

const Footer = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="relative py-8 px-4 md:px-8 lg:px-16 border-t border-[#1a1a1a]">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
        {/* Copyright */}
        <p className="font-mono text-xs text-[#888] tracking-wider">
          © 2024 <span className="text-[#f5f5f5]">АЛЕКСАНДРА ВОЛКОВА</span>. ВСЕ ПРАВА ЗАЩИЩЕНЫ.
        </p>

        {/* Back to top */}
        <button
          onClick={scrollToTop}
          className="flex items-center gap-2 font-mono text-xs text-[#888] tracking-wider hover:text-[#ff2d55] transition-colors group"
          data-cursor-hover
        >
          <span>НАВЕРХ</span>
          <ArrowUp className="w-4 h-4 group-hover:-translate-y-1 transition-transform" />
        </button>
      </div>
    </footer>
  );
};

export default Footer;
