import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowUpRight } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface Project {
  id: number;
  title: string;
  category: string;
  image: string;
}

const projects: Project[] = [
  { id: 1, title: 'NEON DREAMS', category: 'Брендинг', image: '/project1.jpg' },
  { id: 2, title: 'QUANTUM', category: 'Визуальная идентичность', image: '/project2.jpg' },
  { id: 3, title: 'ORGANIC', category: 'Упаковка', image: '/project3.jpg' },
  { id: 4, title: 'TYPOGRAPHY', category: 'Editorial', image: '/project4.jpg' },
  { id: 5, title: 'MOTION', category: 'Моушн-дизайн', image: '/project5.jpg' },
  { id: 6, title: 'DIGITAL', category: 'Веб-дизайн', image: '/project6.jpg' },
];

const Works = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const gridRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    const title = titleRef.current;
    const grid = gridRef.current;

    if (!section || !title || !grid) return;

    const ctx = gsap.context(() => {
      // Title animation
      gsap.fromTo(title, 
        { opacity: 0, y: 60 },
        {
          opacity: 1,
          y: 0,
          duration: 1,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: title,
            start: 'top 80%',
            toggleActions: 'play none none reverse'
          }
        }
      );

      // Project cards animation
      const cards = grid.querySelectorAll('.project-card');
      cards.forEach((card, i) => {
        const isLeft = i % 2 === 0;
        
        gsap.fromTo(card,
          { 
            opacity: 0, 
            y: 80,
            x: isLeft ? -30 : 30
          },
          {
            opacity: 1,
            y: 0,
            x: 0,
            duration: 1,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: card,
              start: 'top 85%',
              toggleActions: 'play none none reverse'
            }
          }
        );

        // Parallax effect on images
        const img = card.querySelector('img');
        if (img) {
          gsap.to(img, {
            yPercent: -15,
            ease: 'none',
            scrollTrigger: {
              trigger: card,
              start: 'top bottom',
              end: 'bottom top',
              scrub: true
            }
          });
        }
      });
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section 
      ref={sectionRef}
      id="works" 
      className="relative py-32 px-4 md:px-8 lg:px-16"
    >
      {/* Section title */}
      <div className="max-w-7xl mx-auto mb-20">
        <h2 
          ref={titleRef}
          className="font-display font-bold text-[#f5f5f5] tracking-[-0.03em]"
          style={{ fontSize: 'clamp(3rem, 8vw, 6rem)' }}
        >
          РАБОТЫ
        </h2>
        <p className="mt-4 font-mono text-sm text-[#888] tracking-widest">
          ИЗБРАННЫЕ ПРОЕКТЫ / 2020—2024
        </p>
      </div>

      {/* Projects grid */}
      <div 
        ref={gridRef}
        className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12"
      >
        {projects.map((project, index) => (
          <div
            key={project.id}
            className={`project-card group relative ${
              index % 2 === 0 ? 'md:-mt-0' : 'md:mt-24'
            }`}
            data-cursor-hover
          >
            {/* Project number */}
            <span 
              className="absolute -top-8 -left-4 font-display font-bold text-[8rem] md:text-[12rem] text-[#1a1a1a] leading-none -z-10 select-none pointer-events-none group-hover:text-[#ff2d55]/10 transition-colors duration-500"
            >
              {String(project.id).padStart(2, '0')}
            </span>

            {/* Image container */}
            <div className="relative overflow-hidden rounded aspect-[3/4] img-zoom running-border">
              <img
                src={project.image}
                alt={project.title}
                className="w-full h-full object-cover scale-110"
              />
              
              {/* Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0a]/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              
              {/* Glitch overlay */}
              <div 
                className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none"
                style={{
                  background: 'linear-gradient(90deg, rgba(255,45,85,0.1) 0%, transparent 50%, rgba(0,212,255,0.1) 100%)',
                  mixBlendMode: 'overlay'
                }}
              />

              {/* View project button */}
              <div className="absolute bottom-6 left-6 right-6 flex items-end justify-between opacity-0 group-hover:opacity-100 transform translate-y-4 group-hover:translate-y-0 transition-all duration-500">
                <div>
                  <p className="font-mono text-xs text-[#888] tracking-widest mb-1">
                    {project.category.toUpperCase()}
                  </p>
                  <h3 className="font-display font-bold text-xl md:text-2xl text-[#f5f5f5]">
                    {project.title}
                  </h3>
                </div>
                <div className="w-12 h-12 rounded-full border border-[#f5f5f5]/30 flex items-center justify-center group-hover:bg-[#ff2d55] group-hover:border-[#ff2d55] transition-all duration-300">
                  <ArrowUpRight className="w-5 h-5 text-[#f5f5f5]" />
                </div>
              </div>
            </div>

            {/* Project info (visible on mobile) */}
            <div className="mt-4 md:hidden">
              <p className="font-mono text-xs text-[#888] tracking-widest">
                {project.category.toUpperCase()}
              </p>
              <h3 className="font-display font-bold text-lg text-[#f5f5f5] mt-1">
                {project.title}
              </h3>
            </div>
          </div>
        ))}
      </div>

      {/* View all button */}
      <div className="max-w-7xl mx-auto mt-20 text-center">
        <button 
          className="inline-flex items-center gap-3 px-8 py-4 border border-[#1a1a1a] hover:border-[#ff2d55] text-[#f5f5f5] font-mono text-sm tracking-widest transition-all duration-300 group"
          data-cursor-hover
        >
          <span>ВСЕ ПРОЕКТЫ</span>
          <ArrowUpRight className="w-4 h-4 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
        </button>
      </div>
    </section>
  );
};

export default Works;
