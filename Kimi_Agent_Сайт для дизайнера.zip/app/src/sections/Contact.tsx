import { useEffect, useRef, useCallback } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight, Mail } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
}

const Contact = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const buttonRef = useRef<HTMLAnchorElement>(null);
  const particlesRef = useRef<Particle[]>([]);
  const mouseRef = useRef({ x: 0, y: 0 });
  const animationRef = useRef<number | null>(null);

  // Initialize particles
  const initParticles = useCallback((width: number, height: number) => {
    const particles: Particle[] = [];
    const count = Math.min(50, Math.floor((width * height) / 20000));
    
    for (let i = 0; i < count; i++) {
      particles.push({
        x: Math.random() * width,
        y: Math.random() * height,
        vx: (Math.random() - 0.5) * 0.5,
        vy: (Math.random() - 0.5) * 0.5,
        radius: Math.random() * 2 + 1
      });
    }
    
    particlesRef.current = particles;
  }, []);

  // Animation loop
  const animate = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;
    const mouse = mouseRef.current;

    ctx.clearRect(0, 0, width, height);

    particlesRef.current.forEach((particle, i) => {
      // Mouse repulsion
      const dx = particle.x - mouse.x;
      const dy = particle.y - mouse.y;
      const dist = Math.sqrt(dx * dx + dy * dy);
      
      if (dist < 100) {
        const force = (100 - dist) / 100;
        particle.vx += (dx / dist) * force * 0.5;
        particle.vy += (dy / dist) * force * 0.5;
      }

      // Update position
      particle.x += particle.vx;
      particle.y += particle.vy;

      // Friction
      particle.vx *= 0.98;
      particle.vy *= 0.98;

      // Bounce off walls
      if (particle.x < 0 || particle.x > width) particle.vx *= -1;
      if (particle.y < 0 || particle.y > height) particle.vy *= -1;

      // Keep in bounds
      particle.x = Math.max(0, Math.min(width, particle.x));
      particle.y = Math.max(0, Math.min(height, particle.y));

      // Draw particle
      ctx.beginPath();
      ctx.arc(particle.x, particle.y, particle.radius, 0, Math.PI * 2);
      ctx.fillStyle = i % 3 === 0 ? 'rgba(255, 45, 85, 0.6)' : 'rgba(0, 212, 255, 0.4)';
      ctx.fill();

      // Draw connections
      particlesRef.current.slice(i + 1).forEach((other) => {
        const ddx = particle.x - other.x;
        const ddy = particle.y - other.y;
        const distance = Math.sqrt(ddx * ddx + ddy * ddy);

        if (distance < 100) {
          ctx.beginPath();
          ctx.moveTo(particle.x, particle.y);
          ctx.lineTo(other.x, other.y);
          ctx.strokeStyle = `rgba(255, 255, 255, ${0.1 * (1 - distance / 100)})`;
          ctx.stroke();
        }
      });
    });

    animationRef.current = requestAnimationFrame(animate);
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    const section = sectionRef.current;
    if (!canvas || !section) return;

    const handleResize = () => {
      canvas.width = section.offsetWidth;
      canvas.height = section.offsetHeight;
      initParticles(canvas.width, canvas.height);
    };

    handleResize();
    window.addEventListener('resize', handleResize);

    const handleMouseMove = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect();
      mouseRef.current = {
        x: e.clientX - rect.left,
        y: e.clientY - rect.top
      };
    };

    section.addEventListener('mousemove', handleMouseMove, { passive: true });
    animate();

    return () => {
      window.removeEventListener('resize', handleResize);
      section.removeEventListener('mousemove', handleMouseMove);
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [initParticles, animate]);

  useEffect(() => {
    const section = sectionRef.current;
    const content = contentRef.current;
    const button = buttonRef.current;

    if (!section || !content || !button) return;

    const ctx = gsap.context(() => {
      // Content animation
      const elements = content.querySelectorAll('.animate-in');
      gsap.fromTo(elements,
        { opacity: 0, y: 50 },
        {
          opacity: 1,
          y: 0,
          duration: 0.8,
          stagger: 0.15,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: content,
            start: 'top 75%',
            toggleActions: 'play none none reverse'
          }
        }
      );

      // Magnetic button effect
      const handleMouseMove = (e: MouseEvent) => {
        const rect = button.getBoundingClientRect();
        const centerX = rect.left + rect.width / 2;
        const centerY = rect.top + rect.height / 2;
        const distX = e.clientX - centerX;
        const distY = e.clientY - centerY;
        const distance = Math.sqrt(distX * distX + distY * distY);

        if (distance < 150) {
          const strength = (150 - distance) / 150;
          gsap.to(button, {
            x: distX * strength * 0.3,
            y: distY * strength * 0.3,
            duration: 0.3,
            ease: 'power2.out'
          });
        } else {
          gsap.to(button, {
            x: 0,
            y: 0,
            duration: 0.5,
            ease: 'elastic.out(1, 0.5)'
          });
        }
      };

      const handleMouseLeave = () => {
        gsap.to(button, {
          x: 0,
          y: 0,
          duration: 0.5,
          ease: 'elastic.out(1, 0.5)'
        });
      };

      section.addEventListener('mousemove', handleMouseMove, { passive: true });
      button.addEventListener('mouseleave', handleMouseLeave);

      return () => {
        section.removeEventListener('mousemove', handleMouseMove);
        button.removeEventListener('mouseleave', handleMouseLeave);
      };
    }, section);

    return () => ctx.revert();
  }, []);

  const socialLinks = [
    { name: 'BEHANCE', url: '#' },
    { name: 'DRIBBBLE', url: '#' },
    { name: 'INSTAGRAM', url: '#' },
    { name: 'TELEGRAM', url: '#' },
  ];

  return (
    <section 
      ref={sectionRef}
      id="contact" 
      className="relative min-h-screen flex items-center justify-center py-32 px-4 md:px-8 lg:px-16 overflow-hidden"
    >
      {/* Particle canvas */}
      <canvas 
        ref={canvasRef}
        className="absolute inset-0 pointer-events-none"
      />

      {/* Content */}
      <div ref={contentRef} className="relative z-10 text-center max-w-4xl mx-auto">
        <p className="animate-in font-mono text-xs text-[#ff2d55] tracking-[0.3em] uppercase mb-8">
          Контакты
        </p>

        <h2 
          className="animate-in font-display font-bold text-[#f5f5f5] tracking-[-0.03em] mb-12"
          style={{ fontSize: 'clamp(2rem, 6vw, 4rem)' }}
        >
          ДАВАЙТЕ СОЗДАДИМ<br />
          <span className="text-[#888]">ЧТО-ТО УНИКАЛЬНОЕ</span>
        </h2>

        {/* Magnetic button */}
        <a
          ref={buttonRef}
          href="mailto:hello@volkovadesign.ru"
          className="animate-in inline-flex items-center justify-center w-48 h-48 md:w-64 md:h-64 rounded-full border-2 border-[#ff2d55] text-[#f5f5f5] font-display font-bold text-lg md:text-xl tracking-wider hover:bg-[#ff2d55] transition-colors duration-500 group magnetic-btn"
          data-cursor-hover
        >
          <span className="flex flex-col items-center gap-2">
            <span>НАПИСАТЬ</span>
            <ArrowRight className="w-6 h-6 group-hover:translate-x-2 transition-transform" />
          </span>
        </a>

        {/* Email */}
        <div className="animate-in mt-12 flex items-center justify-center gap-3 text-[#888]">
          <Mail className="w-4 h-4" />
          <a 
            href="mailto:hello@volkovadesign.ru"
            className="font-mono text-sm tracking-wider hover:text-[#ff2d55] transition-colors"
            data-cursor-hover
          >
            hello@volkovadesign.ru
          </a>
        </div>

        {/* Social links */}
        <div className="animate-in mt-16 flex flex-wrap justify-center gap-6 md:gap-10">
          {socialLinks.map((link) => (
            <a
              key={link.name}
              href={link.url}
              className="font-mono text-xs text-[#888] tracking-[0.2em] hover:text-[#ff2d55] transition-colors link-underline"
              data-cursor-hover
            >
              {link.name}
            </a>
          ))}
        </div>
      </div>

      {/* Decorative elements */}
      <div className="absolute top-1/4 left-10 w-2 h-2 rounded-full bg-[#ff2d55] opacity-50" />
      <div className="absolute bottom-1/3 right-16 w-3 h-3 rounded-full bg-[#00d4ff] opacity-30" />
      <div className="absolute top-1/2 right-1/4 w-1 h-1 rounded-full bg-[#f5f5f5] opacity-40" />
    </section>
  );
};

export default Contact;
